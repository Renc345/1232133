﻿using Microsoft.Office.Interop.Excel;
using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataVis = System.Windows.Forms.DataVisualization;
using System.Drawing;
using Page = System.Windows.Controls.Page;
using Microsoft.Win32;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDiagrama.xaml
    /// </summary>
    public partial class PageDiagrama : Page
    {
        public PageDiagrama()
        {
            InitializeComponent();
            cmbYear.ItemsSource = GetYears();
            cmbYear.SelectedIndex = cmbYear.Items.Count - 1;

            CreatingСhart(0, int.Parse(cmbYear.SelectedItem.ToString()));
            chartArrivals.ChartAreas[0].AxisY.Title = "Продажа";

            chartArrivals.Series[0].Font = new System.Drawing.Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisX.TitleFont = new System.Drawing.Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisY.TitleFont = new System.Drawing.Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisX.LabelStyle.Font = new System.Drawing.Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisY.LabelStyle.Font = new System.Drawing.Font("Segoe UI", 12);
            chartArrivals.Series[0].BorderWidth = 5;
        }
        public void CreatingChartTitle()
        {
            string title = "Диаграмма поступлений";
            if (rbQuarter.IsChecked == true) title += " по кварталам за " + cmbYear.SelectedItem.ToString() + " год";
            else if (rbMonth.IsChecked == true) title += " по месяцам за " + cmbYear.SelectedItem.ToString() + " год";
            else title += " по годам";
            txbChartTitle.Text = title;
            ShowTitle_Click(null, null);
        }

        public List<int> GetYears()
        {
            List<int> Years = new List<int>();
            foreach (ExpenseIvoices invoice in ClassFrame.db.ExpenseIvoices.ToList()) if (invoice.Date_Transfer != null) Years.Add(((DateTime)invoice.Date_Transfer).Year);
            return Years.Distinct().OrderBy(x => x).ToList();
        }

        public void CreatingСhart(int mode, int year)
        {
            chartArrivals.Series[0].Points.Clear();
            if (mode == 0)
            {
                List<ExpenseIvoices> list = ClassFrame.db.ExpenseIvoices.ToList().Where(x => x.Date_Transfer != null && ((DateTime)x.Date_Transfer).Year == year).ToList();
                int Quarter1 = 0;
                int Quarter2 = 0;
                int Quarter3 = 0;
                int Quarter4 = 0;
                foreach (ExpenseIvoices invoice in list)
                {
                    if (invoice.Date_Transfer >= new DateTime(year, 1, 1, 0, 0, 0) && invoice.Date_Transfer < new DateTime(year, 3, 31, 0, 0, 0)) Quarter1++;
                    else if (invoice.Date_Transfer >= new DateTime(year, 4, 1, 0, 0, 0) && invoice.Date_Transfer < new DateTime(year, 6, 30, 0, 0, 0)) Quarter2++;
                    else if (invoice.Date_Transfer >= new DateTime(year, 7, 1, 0, 0, 0) && invoice.Date_Transfer < new DateTime(year, 3, 30, 0, 0, 0)) Quarter3++;
                    else Quarter4++;
                }
                chartArrivals.Series[0].Points.Add(Quarter1).AxisLabel = "I";
                chartArrivals.Series[0].Points.Add(Quarter2).AxisLabel = "II";
                chartArrivals.Series[0].Points.Add(Quarter3).AxisLabel = "III";
                chartArrivals.Series[0].Points.Add(Quarter4).AxisLabel = "IV";
                chartArrivals.ChartAreas[0].AxisX.Title = "Кварталы";
            }
            else if (mode == 1)
            {
                List<ExpenseIvoices> list = ClassFrame.db.ExpenseIvoices.ToList().Where(x => ((DateTime)x.Date_Transfer).Year == year).ToList();
                int[] Months = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                foreach (ExpenseIvoices invoice in list)
                {
                    int Month = ((DateTime)invoice.Date_Transfer).Month;
                    Months[Month - 1]++;
                }
                for (int i = 0; i < Months.Length; i++) chartArrivals.Series[0].Points.Add(Months[i]).AxisLabel = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(i + 1);
                chartArrivals.ChartAreas[0].AxisX.Title = "Месяцы";
            }
            else
            {
                foreach (int y in GetYears()) chartArrivals.Series[0].Points.Add(ClassFrame.db.ExpenseIvoices.ToList().Where(x => ((DateTime)x.Date_Transfer).Year == y).ToList().Count()).AxisLabel = y.ToString();
                chartArrivals.ChartAreas[0].AxisX.Title = "Года";
            }
            CreatingChartTitle();
        }

        private void CmbYear_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int year = int.Parse(cmbYear.SelectedItem.ToString());
            if (rbQuarter.IsChecked == true) CreatingСhart(0, year);
            else if (rbMonth.IsChecked == true) CreatingСhart(1, year);
            else CreatingСhart(2, year);
        }

        private void ReportType_Click(object sender, RoutedEventArgs e)
        {
            int year = int.Parse(cmbYear.SelectedItem.ToString());
            switch (((RadioButton)sender).Name)
            {
                case "rbQuarter":
                    cmbYear.IsEnabled = true;
                    CreatingСhart(0, year);
                    break;
                case "rbMonth":
                    cmbYear.IsEnabled = true;
                    CreatingСhart(1, year);
                    break;
                case "rbYear":
                    cmbYear.IsEnabled = false;
                    CreatingСhart(2, year);
                    break;
                default:
                    break;
            }
        }

        private void ReportType_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            RadioButton rb = new RadioButton();
            switch (((TextBlock)sender).Text)
            {
                case "По кварталам":
                    rb = rbQuarter;
                    break;
                case "По месяцам":
                    rb = rbMonth;
                    break;
                case "По годам":
                    rb = rbYear;
                    break;
                default:
                    break;
            }
            rb.IsChecked = true;
            ReportType_Click(rb, null);
        }

        private void ChartType_Click(object sender, RoutedEventArgs e)
        {
            switch (((RadioButton)sender).Name)
            {
                case "rbColumn":
                    chartArrivals.Series[0].ChartType = DataVis.Charting.SeriesChartType.Column;
                    break;
                case "rbBar":
                    chartArrivals.Series[0].ChartType = DataVis.Charting.SeriesChartType.Bar;
                    break;
                case "rbPie":
                    chartArrivals.Series[0].ChartType = DataVis.Charting.SeriesChartType.Pie;
                    break;
                case "rbLine":
                    chartArrivals.Series[0].ChartType = DataVis.Charting.SeriesChartType.Line;
                    break;
                default:
                    break;
            }
        }

        private void ChartType_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            RadioButton rb = new RadioButton();
            switch (((TextBlock)sender).Text)
            {
                case "Гистограмма":
                    rb = rbColumn;
                    break;
                case "Линейчатая":
                    rb = rbBar;
                    break;
                case "Круговая":
                    rb = rbPie;
                    break;
                case "График":
                    rb = rbLine;
                    break;
                default:
                    break;
            }
            rb.IsChecked = true;
            ChartType_Click(rb, null);
        }

        private void TxbChartTitle_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txbChartTitle.Text == "") chartArrivals.Titles.Clear();
            else
            {
                if (chartArrivals.Titles.Count == 0)
                {
                    chartArrivals.Titles.Add(txbChartTitle.Text);
                    chartArrivals.Titles[0].Font = new System.Drawing.Font("Segoe UI", 15, System.Drawing.FontStyle.Bold);
                }
                else chartArrivals.Titles[0].Text = txbChartTitle.Text;
            }
        }

        private void ShowTitle_Click(object sender, RoutedEventArgs e)
        {
            if (cbShowTitle.IsChecked == true) chartArrivals.Titles.Clear();
            else
            {
                if (chartArrivals.Titles.Count == 0)
                {
                    chartArrivals.Titles.Add(txbChartTitle.Text);
                    chartArrivals.Titles[0].Font = new System.Drawing.Font("Segoe UI", 15, System.Drawing.FontStyle.Bold);
                }
                else chartArrivals.Titles[0].Text = txbChartTitle.Text;
            }
        }

        private void ShowTitle_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbShowTitle.IsChecked = !cbShowTitle.IsChecked;
            ShowTitle_Click(null, null);
        }

        private void ShowValues_Click(object sender, RoutedEventArgs e)
        {
            chartArrivals.Series[0].IsValueShownAsLabel = (bool)cbShowValues.IsChecked;
        }

        private void ShowValues_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbShowValues.IsChecked = !cbShowValues.IsChecked;
            chartArrivals.Series[0].IsValueShownAsLabel = (bool)cbShowValues.IsChecked;
        }

        private void BackColor_Click(object sender, RoutedEventArgs e)
        {
            chartArrivals.Series[0].LabelBackColor = cbBackColor.IsChecked == true ? System.Drawing.Color.White: System.Drawing.Color.Transparent;
        }

        private void BackColor_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbBackColor.IsChecked = !cbBackColor.IsChecked;
            chartArrivals.Series[0].LabelBackColor = cbBackColor.IsChecked == true ? System.Drawing.Color.White : System.Drawing.Color.Transparent;
        }

        private void ColourDropDown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (ColourDropDown.SelectedIndex)
            {
                case 0:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.BrightPastel;
                    break;
                case 1:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.Berry;
                    break;
                case 2:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.Pastel;
                    break;
                case 3:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.Grayscale;
                    break;
                case 4:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.SemiTransparent;
                    break;
                default:
                    break;
            }
        }

        private void BtnExportChart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog { Filter = "PNG (*.png)|*.png|JPG (*.jpg)|*.jpg|JPEG (*.jpeg)|*.jpeg", Title = "Выберите фото/изображение пользователя", FileName = txbChartTitle.Text };
                if (sfd.ShowDialog() == true)
                {
                    var ChartBmp = new Bitmap(chartArrivals.Size.Width, chartArrivals.Size.Height);
                    var ChartBounds = new System.Drawing.Rectangle(0, 0, chartArrivals.Size.Width, chartArrivals.Size.Height);
                    chartArrivals.DrawToBitmap(ChartBmp, ChartBounds);
                    ChartBmp.Save(sfd.FileName);
                    MessageBox.Show("Изображение диаграммы успешно сохранено!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
    }
}
