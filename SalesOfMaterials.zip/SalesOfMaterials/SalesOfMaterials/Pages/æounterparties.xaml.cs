﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для Сounterparties.xaml
    /// </summary>
    public partial class Сounterparties : Page
    {
        public Сounterparties()
        {
            InitializeComponent();
            dgСounterparties.ItemsSource = ClassFrame.db.Сounterparties.ToList();
        }
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtSearch.Text.Count() != 0)
                dgСounterparties.ItemsSource = ClassFrame.db.Сounterparties.Where(x => x.Nazv_Сounterparties.Contains(txtSearch.Text.ToLower()) || x.INN.Contains(txtSearch.Text.ToLower()) || x.Adress_Сounterparties.Contains(txtSearch.Text.ToLower())).ToList();
            else dgСounterparties.ItemsSource = ClassFrame.db.Сounterparties.ToList();
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddСounterparties(null));
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddСounterparties((Classes.Сounterparties)dgСounterparties.SelectedItem));
        }

        private void MenuFilter_Click(object sender, RoutedEventArgs e)
        {
            MenuItem m = sender as MenuItem;
            List<Classes.Сounterparties> list = new List<Classes.Сounterparties>();
            switch (m.Header)
            {
                case "ООО":
                    foreach (Classes.Сounterparties c in ClassFrame.db.Сounterparties.ToList())
                        if (c.Nazv_Сounterparties.Split(' ')[0] == "ООО") list.Add(c);
                    dgСounterparties.ItemsSource = list;
                    break;
                case "АО":
                    foreach (Classes.Сounterparties c in ClassFrame.db.Сounterparties.ToList())
                        if (c.Nazv_Сounterparties.Split(' ')[0] == "АО") list.Add(c);
                    dgСounterparties.ItemsSource = list;
                    break;
            }
        }

        private void MenuClear_Click(object sender, RoutedEventArgs e)
        {
            dgСounterparties.ItemsSource = ClassFrame.db.Сounterparties.ToList();
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dgСounterparties.ItemsSource = ClassFrame.db.Сounterparties.ToList();
        }

        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void MenuDelet_Click(object sender, RoutedEventArgs e)
        {
            List<Classes.Сounterparties> delet = dgСounterparties.SelectedItems.Cast<Classes.Сounterparties>().ToList();
            if (MessageBox.Show("Удалить контрагента", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ClassFrame.db.Сounterparties.RemoveRange(delet);
                    ClassFrame.db.SaveChanges();
                    MessageBox.Show("Данные удаленны");
                    dgСounterparties.ItemsSource = ClassFrame.db.Сounterparties.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
