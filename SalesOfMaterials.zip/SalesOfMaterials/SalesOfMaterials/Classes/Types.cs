﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    public class Types
    {
        public int idType { get; set; }
        public string Name { get; set; }
    }
}
